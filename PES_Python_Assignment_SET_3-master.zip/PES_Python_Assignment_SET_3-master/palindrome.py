def palindrome(input1):
    if input1 == input1[::-1]:
        print(input1,'is a Palindrome')
    else:
        print(input1,'is not a palindrome')

input = raw_input("Enter a Word to check if its a Palindrome : ")